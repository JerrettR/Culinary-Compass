const mysql = require('mysql');

const pool  = mysql.createPool({
    connectionLimit: 10,
    host: "uzb4o9e2oe257glt.cbetxkdyhwsb.us-east-1.rds.amazonaws.com",
    user: "i4ft5vs59gt7vnoh",
    password: "mjpvkx8jiupo61s5",
    database: "y87lekvpr5g6041b"
});

module.exports = pool;