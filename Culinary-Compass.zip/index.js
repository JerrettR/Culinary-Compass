const express = require("express");
const mysql = require("mysql");
const app = express();
const session = require("express-session");
const bcrypt = require("bcrypt");
const pool = require("./dbPool");
let isAdmin = false;
let userId = 0;

app.set("view engine", "ejs");

app.use(express.static("public"));
app.use(express.urlencoded({ extended: true })); //to be able to parse POST parameters
app.use(
  session({
    secret: "top secret!",
    resave: true,
    saveUninitialized: true,
  })
);

//routes
app.get("/", (req, res) => {
  res.render("index");
});

app.post("/", async (req, res) => {
  let username = req.body.username;
  let password = req.body.password;
  let hashedPwd = "";

  let sql1 = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows1 = await executeSQL(sql1);

  let sql = "SELECT * FROM users WHERE username = ?";
  let rows = await executeSQL(sql, [username]);
  let userType = rows[0].userType;

  if (userType == "admin") {
    isAdmin = true;
    userId = 1;
  } else {
    isAdmin = false;
    userId = 2;
  }

  if (rows.length > 0) {
    hashedPwd = rows[0].password;
  }

  let passwordMatch = await bcrypt.compare(password, hashedPwd);

  if (passwordMatch) {
    // set authentication and userId in the session
    req.session.authenticated = true;
    req.session.userId = userId;
    res.render("home", { isAdmin: isAdmin, categories:rows1 });
  } else {
    res.render("index", { loginError: true });
  }
});

app.get("/home", async (req, res) => {
  let sql = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows = await executeSQL(sql);
  
  // should still render if not admin, omitted for now...
  // if (req.session.authenticated) {
  res.render("home", {"isAdmin":isAdmin, categories:rows});
  // }
});

app.get("/newRecipe", async (req, res) => {
  let sql = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows = await executeSQL(sql);
  
  if (req.session.authenticated) {
    res.render("newRecipe", { isAdmin: isAdmin, categories:rows });
  }
});

app.get("/listRecipes", async (req, res) => {
  let sql1 = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows1 = await executeSQL(sql1);
  
  if (req.session.authenticated) {
    let sql = `SELECT *
               FROM recipes
               ORDER BY title`;
    let rows = await executeSQL(sql);
    res.render("listRecipes", { isAdmin: isAdmin, recipeInfo: rows, categories:rows1 });
  }
});

app.get("/recipe/edit", async function (req, res) {
  try {
    let recipeId = req.query.recipeId;
    let sql = `SELECT *
               FROM recipes
               WHERE recipeId = ${recipeId}`;
    let rows = await executeSQL(sql);
    console.log(rows);

    let sql1 = `SELECT DISTINCT category
               FROM recipes
               ORDER BY category;`
    let categories = await executeSQL(sql1); 

    let sql2 = `SELECT DISTINCT category
               FROM recipes
               WHERE category != '${rows[0].category}'
               ORDER BY category;`
    let rows2 = await executeSQL(sql2); 
    
    res.render("editRecipe", { isAdmin: isAdmin, recipeInfo: rows, categories: categories, categories2: rows2 });
  } catch (error) {
    console.error("Error in /recipe/edit route:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.post("/recipe/edit", async function (req, res) {
  let sql = `UPDATE recipes
             SET title = ?,
             authorFirstName = ?,
             authorLastName = ?,
             category = ?,
             directions = ?,
             time = ?,
             servings = ?,
             pictureUrl = ?
             WHERE recipeId = ?`;
  let params = [
    req.body.title,
    req.body.fName,
    req.body.lName,
    req.body.category,
    req.body.directions,
    req.body.time,
    req.body.servings,
    req.body.picture,
    req.body.recipeId,
  ];
  let rows = await executeSQL(sql, params);

  let recipeId = req.body.recipeId;
  sql1 = `SELECT *
          FROM recipes
          WHERE recipeId = ${recipeId}`;
  let rows1 = await executeSQL(sql1);

  let sql2 = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let categories = await executeSQL(sql2); 

  let sql3 = `SELECT DISTINCT category
             FROM recipes
             WHERE category != '${rows1[0].category}'
             ORDER BY category;`
  let rows3 = await executeSQL(sql3); 

  res.render("editRecipe", {
    isAdmin: isAdmin,
    recipeInfo: rows1,
    categories: categories,
    categories2: rows3,
    message: "Recipe Updated!",
  });
});

app.post("/recipe/add", async function (req, res) {
  let sql = `INSERT INTO recipes 
             (title, authorFirstName, authorLastName, category, directions, time, servings, pictureUrl)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)              `;
  let params = [
    req.body.title,
    req.body.fName,
    req.body.lName,
    req.body.category,
    req.body.directions,
    req.body.time,
    req.body.servings,
    req.body.picture,
  ];
  let rows = await executeSQL(sql, params);

  let recipeId = rows.insertId;
  sql1 = `SELECT *
          FROM recipes
          WHERE recipeId = ${recipeId}`;
  let rows1 = await executeSQL(sql1);

  let sql2 = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows2 = await executeSQL(sql2);

  res.render("editRecipe", {
    isAdmin: isAdmin,
    recipeInfo: rows1,
    categories: rows2,
    message: "Recipe Added!",
  });
});

app.get("/recipe/delete", async function (req, res) {
  let sql = `DELETE
             FROM recipes
             WHERE recipeId = ?`;
  let params = [req.query.recipeId];
  let rows = await executeSQL(sql, params);

  res.redirect("/recipes?deletionSuccess=true");
});

app.get("/shoppingList", async (req, res) => {
  let sql = `SELECT *
               FROM shoppingList
               NATURAL JOIN ingredients
               WHERE userId = ${userId};`;
  let rows = await executeSQL(sql);

  let sql1 = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows1 = await executeSQL(sql1);
  
  res.render("shoppingList", { list: rows, isAdmin: isAdmin, categories:rows1 });
});

// For adding to the shopping list
app.post("/api/shoppingList/:id", async (req, res) => {
  try {
    // const { ingredientId } = req.body;
    // const userId = req.session.userId;
    let ingredientId = req.params.id;
    const sql = `INSERT INTO shoppingList (userId, ingredientId) VALUES (?, ?)`;
    const params = [userId, ingredientId];
    console.log("userId index.js /api/shoppingList : " + userId);
    console.log("ingredientId index.js /api/shoppingList : " + ingredientId);
    await executeSQL(sql, params);

    res.json({
      success: true,
      message: "Ingredient added to the shopping list successfully",
    });
  } catch (error) {
    console.error("Error in /api/shoppingList:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// Update the 'get' route for shoppingList to retrieve the data
app.get("/shoppingList", async (req, res) => {
  try {
    let sql = `SELECT *
               FROM shoppingList
               NATURAL JOIN ingredients
               WHERE userId = ${userId};`;
    let rows = await executeSQL(sql);

    let sql1 = `SELECT DISTINCT category
               FROM recipes
               ORDER BY category;`
    let rows1 = await executeSQL(sql1);
    
    res.render("shoppingList", { list: rows, isAdmin: isAdmin, categories:rows1 });
  } catch (error) {
    console.error(`An error occurred while fetching shopping list: ${error}`);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

app.get("/shoppingList/delete", async (req, res) => {
  let ingredientId = req.query.ingredientId;
  let sql = `DELETE FROM shoppinglist
             WHERE userId = ? AND ingredientId = ?`;
  let params = [userId, ingredientId];
  let rows = await executeSQL(sql, params);
  res.redirect("/shoppingList");
});

app.get("/favorites", async (req, res) => {
  if (req.session.authenticated) {
    const userFavoritesSql = `
        SELECT favoriteId, userId, recipeId, title
        FROM favorites
        NATURAL JOIN recipes
        WHERE userId = ?`;

    const userFavorites = await executeSQL(userFavoritesSql, [
      req.session.userId,
    ]);

    let sql1 = `SELECT DISTINCT category
               FROM recipes
               ORDER BY category;`
    let rows1 = await executeSQL(sql1);
    
    res.render("favorites", { list: userFavorites, isAdmin: isAdmin, categories:rows1 });
  } else {
    res.redirect("/login"); // Redirect to login page or handle as needed
  }
});

app.get("/favorites/delete", async (req, res) => {
  let recipeId = req.query.recipeId;
  console.log(recipeId);
  console.log(userId);
  let sql = `DELETE FROM favorites
             WHERE userId = ? AND recipeId = ?`;
  let params = [userId, recipeId];
  let rows = await executeSQL(sql, params);
  res.redirect("/favorites");
});

app.get("/searchByKeyword", async (req, res) => {
  let userKeyword = req.query.keyword;
  let sql = `SELECT title, recipeId, time
             FROM recipes
             WHERE title LIKE ?`;
  let params = [`%${userKeyword}%`];
  let rows = await executeSQL(sql, params);

  let sql1 = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows1 = await executeSQL(sql1);

  res.render("results", { isAdmin: isAdmin, recipes: rows, categories:rows1 });
});

app.get("/searchByCategory", async (req, res) => {
  let userCategory = req.query.category;
  let sql = `SELECT title, recipeId, time
             FROM recipes
             WHERE category LIKE ?`;
  let params = [`%${userCategory}%`];
  let rows = await executeSQL(sql, params);

  let sql1 = `SELECT DISTINCT category
             FROM recipes
             ORDER BY category;`
  let rows1 = await executeSQL(sql1);

  res.render("results", { isAdmin: isAdmin, recipes: rows, categories:rows1 });
});

// Local API for rubric.
app.get("/api/recipes", async (req, res) => {
  let sql = `SELECT *
               FROM recipes
               ORDER BY title`;
  let rows = await executeSQL(sql);

  res.json(rows);
});

//Local API for getting recipe ID
app.get("/api/recipes/:recipeId/:userId", async (req, res) => {
  try {
    const recipeId = parseInt(req.params.recipeId, 10); // Convert to integer
    const userId = parseInt(req.params.userId, 10); // Convert to integer

    // Ensure both recipeId and userId are provided and are valid integers
    if (isNaN(recipeId) || isNaN(userId)) {
      return res.status(400).json({ success: false, message: "Both recipeId and userId must be valid integers." });
    }

    // Fetch recipe details
    let recipeSql = `SELECT *
                     FROM recipes
                     WHERE recipeId = ?`;

    let recipeRows = await executeSQL(recipeSql, [recipeId]);

    // Fetch ingredients for the specified recipeId
    let ingredientsSql = `SELECT *
                          FROM ingredients
                          WHERE recipeId = ?`;

    let ingredientsRows = await executeSQL(ingredientsSql, [recipeId]);

    // Check if the recipe is already in the user's favorites
    let favoritesSql = `SELECT *
                        FROM favorites
                        WHERE userId = ? AND recipeId = ?`;

    let favoritesRows = await executeSQL(favoritesSql, [userId, recipeId]);
    const isFavorite = favoritesRows.length > 0;

    const response = {
      recipe: recipeRows[0],
      ingredients: ingredientsRows,
      isFavorite: isFavorite,
    };

    // Send the recipeId along with the response
    response.recipeId = recipeId;

    res.json(response);
  } catch (error) {
    console.error(`An error occurred during the /api/recipes/:recipeId/:userId route: ${error}`);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

// Define the route for deleting a recipe by recipeId
app.delete('/api/recipes/delete/:recipeId', async (req, res) => {
  try {
    const recipeId = req.params.recipeId;

    // Check if the recipe exists before attempting to delete
    const checkRecipeSql = 'SELECT * FROM recipes WHERE recipeId = ?';
    const checkRecipeResult = await executeSQL(checkRecipeSql, [recipeId]);

    if (checkRecipeResult.length === 0) {
      return res.status(404).json({ success: false, message: 'Recipe not found.' });
    }

    // If the recipe exists, proceed with deletion
    const deleteRecipeSql = 'DELETE FROM recipes WHERE recipeId = ?';
    const deleteRecipeResult = await executeSQL(deleteRecipeSql, [recipeId]);

    if (deleteRecipeResult.affectedRows > 0) {
      res.json({ success: true, message: 'Recipe deleted successfully.' });
    } else {
      res.status(500).json({ success: false, message: 'Failed to delete recipe.' });
    }
  } catch (error) {
    console.error(`An error occurred during the deleteRecipe operation: ${error}`);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
});

//For adding recipe to favorites
app.post("/api/favorites/:id", async (req, res) => {
  try {
    let recipeId = req.params.id;
    // const { userId, recipeId } = req.body;
    // const { recipeId } = req.body;
    // Use req.session.userId as the userId
    const sql = `INSERT INTO favorites (userId, recipeId) VALUES (?, ?)`;
    const params = [userId, recipeId];
    await executeSQL(sql, params);

    res.json({
      success: true,
      message: "Recipe added to favorites successfully",
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
});

//API for current user id
app.get("/api/currentUser", (req, res) => {
  const userId = req.session.userId;
  res.json({ userId, isAdmin });
});

//dbTest
app.get("/dbTest", async function (req, res) {
  let sql = "SELECT CURDATE()";
  let rows = await executeSQL(sql);
  res.send(rows);
});

//functions
function isAuthenticated(req, res, next) {
  if (!req.session.authenticated) {
    res.redirect("/");
  } else {
    next();
  }
};

app.get("/logout", isAuthenticated, (req, res) => {
  req.session.destroy();
  res.redirect("/");
});

//executeSQL
async function executeSQL(sql, params) {
  return new Promise(function (resolve, reject) {
    pool.query(sql, params, function (err, rows, fields) {
      if (err) throw err;
      resolve(rows);
    });
  });
}

//start server
app.listen(3000, () => {
  console.log("Expresss server running...");
});
