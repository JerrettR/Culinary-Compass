changeBackgroundPicture();

const recpieDiv = document.querySelector('#recipesHome-cards');
const getRecipies = async () => {
  try {
    const response = await fetch('https://culinary-compass.djrettro.repl.co/api/recipes')
    const data = await response.json()

    console.log('Testing!', data)

    data.forEach(recipe => {
      recpieDiv.innerHTML += `
      <div class="recipe-card">
        <img class="recipe-card-img" src='${recipe.pictureUrl}'>
        <p class='recipe-card-title'>${recipe.title}</p>
     </div>
     `
    })
  } catch (e) {
    console.log('error', e)
  }

};

getRecipies();

async function changeBackgroundPicture() {
  let url = "https://api.unsplash.com/photos/random/?client_id=RLF0iIfJq6T3vQf-de5R_cqpbV52hlWlxT5Z1V5hVTU&featured=true&query=food";
  let response = await fetch(url);
  let data = await response.json();
  let imageUrl = data.urls.full;

  document.querySelector("#main-page").style.backgroundImage = `url("${imageUrl}")`;
};