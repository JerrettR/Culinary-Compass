// Event listener for recipe links
document.body.addEventListener("click", function (event) {
  if (event.target.classList.contains("recipe-link")) {
    getRecipe.call(event.target);
  }
});

// Function to get recipe based on id
async function getRecipe() {
  try {
    // Fetch the current user's ID from the server
    const currentUserUrl = '/api/currentUser';
    const currentUserResponse = await fetch(currentUserUrl);
    const currentUserData = await currentUserResponse.json();
    const userId = currentUserData.userId;
    let isAdmin = currentUserData.isAdmin;

    // Extract recipeId from the clicked link's id
    const recipeId = this.id;

    // Display modal
    const myModal = new bootstrap.Modal(document.getElementById('recipeModal'));
    myModal.show();

    // Fetch recipe data
    let url = `/api/recipes/${recipeId}/${userId}`;
    let response = await fetch(url);
    let data = await response.json();
    let recipeInfo = document.querySelector("#recipeInfo");

    // Display general recipe information, including author's name
    recipeInfo.innerHTML = `<h1>${data.recipe.title}</h1>
      <img src="${data.recipe.pictureUrl}" width="200" alt="Image of Dish">
      <p><strong>Author: </strong> ${data.recipe.authorFirstName} ${data.recipe.authorLastName}</p>
      <p><strong>Category: </strong> ${data.recipe.category}</p>
      <p><strong>Directions: </strong> ${data.recipe.directions}</p>
      <p><strong>Time: </strong> ${data.recipe.time}</p>
      <p><strong>Servings: </strong> ${data.recipe.servings}</p>
      <hr>
      <h2>Ingredients</h2><br>`;

    // Display each ingredient without amount and measurement
    data.ingredients.forEach((ingredient) => {
      recipeInfo.innerHTML += `
        <p><strong>Ingredient: </strong> ${ingredient.ingredient}</p>
        <button class="btn btn-outline-primary addToShoppingListBtn" data-ingredient-id="${ingredient.ingredientId}">Add to Shopping List</button>
        <br>`;
    });

    if (isAdmin) {
      let modalFooter = document.querySelector("#update-delete-results");
      modalFooter.innerHTML = `
            <button type="button" class="btn btn-warning btn-md edit-recipe-btn mute" id="editRecipeBtn">
              <a href="/recipe/edit?recipeId=${data.recipe.recipeId}">Edit Recipe</a>
            </button>
            <button type="button" class="btn btn-danger btn-md delete-recipe-btn" id="deleteRecipeBtn" data-recipe-id="${data.recipe.recipeId}">Delete Recipe</button>`
    }

    // Add event listener for "Add to Shopping List" buttons
    recipeInfo.addEventListener("click", function (event) {
      if (event.target.classList.contains("addToShoppingListBtn")) {
        const ingredientId = event.target.getAttribute("data-ingredient-id");
        addToShoppingList(userId, data.recipe.recipeId, ingredientId);
      }
    });

    // Add event listener to the Add to Favorites button if it exists
    const saveToFavoritesBtn = document.getElementById('saveToFavoritesBtn');
    if (saveToFavoritesBtn) {
      saveToFavoritesBtn.addEventListener('click', () => saveToFavorites(userId, data.recipe.recipeId));
    }

    // Add event listeners for the new buttons if they exist
    const editRecipeBtn = document.querySelector('.editRecipeBtn');
    const deleteRecipeBtn = document.querySelector('.deleteRecipeBtn');

    if (editRecipeBtn) {
      editRecipeBtn.addEventListener('click', () => editRecipe(data.recipe.recipeId));
    }

    if (deleteRecipeBtn) {
      deleteRecipeBtn.addEventListener('click', () => deleteRecipe(data.recipe.recipeId));
    }
  } catch (error) {
    console.error(`An error occurred during the getRecipe operation: ${error}`);
    alert('An unexpected error occurred while fetching the recipe');
  }
}

async function addToShoppingList(userId, recipeId, ingredientId) {
  try {
    let url = `/api/shoppingList/${ingredientId}`;
    let options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      //Payload
      body: JSON.stringify({
        userId: userId,
        recipeId: recipeId,
        ingredientId: ingredientId,
      }),
    };

    let response = await fetch(url, options);

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    let result = await response.json();

    if (result.success) {
      
      alert('Ingredient added to the shopping list!');
    } else {
     
      alert('Failed to add ingredient to the shopping list');
    }
  } catch (error) {
    console.error(`An error occurred during the addToShoppingList operation: ${error}`);
    alert('An unexpected error occurred while adding to the shopping list');
  }
}


async function saveToFavorites(userId, recipeId) {
  try {
    let url = `/api/favorites/${recipeId}`;
    let options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      // Payload
      body: JSON.stringify({
        userId: userId,
        recipeId: recipeId,        
      }),
    };

    let response = await fetch(url, options);
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    let result = await response.json();

    if (result.success) {
      
      alert('Recipe saved to favorites!');
    } else {
   
      alert('Failed to save recipe to favorites');
    }
  } catch (error) {
    console.error(`An error occurred during the saveToFavorites operation: ${error}`);
    alert('An unexpected error occurred while saving to favorites');
  }
}

// Functon to close the modal
function closeModal(event) {
  if (event.target === overlay) {
    const myModal = new bootstrap.Modal(document.getElementById('results'));
    myModal.hide();
  }
}


// Add an event listener to the Delete Recipe button
const deleteRecipeBtn = document.getElementById('deleteRecipeBtn');

if (deleteRecipeBtn) {
  deleteRecipeBtn.addEventListener('click', () => {
    // Retrieve the recipe ID from the data-recipe-id attribute
    const recipeId = deleteRecipeBtn.getAttribute('data-recipe-id');

    deleteRecipe(recipeId);
  });
}

// Function to delete recipe
async function deleteRecipe(recipeId) {
  try {
    const url = `/api/recipes/delete/${recipeId}`;
    const options = {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
    };

    const response = await fetch(url, options);

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const result = await response.json();

    if (result.success) {
      alert('Recipe deleted successfully!');
    } else {
      alert('Failed to delete recipe');
    }
  } catch (error) {
    console.error(`An error occurred during the deleteRecipe operation: ${error}`);
    alert('An unexpected error occurred while deleting the recipe');
  }
}
